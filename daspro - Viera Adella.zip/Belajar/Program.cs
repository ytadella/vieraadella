﻿using System;

namespace Belajar;
{
    class Program
    {
        static void main (string[] args)
    }
}
Console.WriteLine("Hello, World!");
