﻿using System;
/*
created by Viera Adella - 2207112586
*/

namespace Daspro
{
    class Program
    {
        //Deklarasi 
        public static int codeA;
        public static int codeB;
        public static int codeC;
        public static int hasilTambah;
        public static int hasilKali;
        public static int hasilKurang;
        public static int hasilBagi;
        public static int kesempatan = 1;
        public static String tebakanA;
        public static String tebakanB;
        public static String tebakanC;
        public static bool bGameStart;


        //Main Method
        static void Main(string[] args)
        {
            bGameStart = true;
            while(bGameStart)
            {
                Console.Clear();
                if(kesempatan <= 3)
                {
                    PlayGame();
                }
                else
                {
                    ShowEnd(false);
                }
                kesempatan++;
            }
            Console.Write("Tekan enter untuk keluar..."); Console.ReadKey();
        }
        static void Init()
        {
            //instansi variabel
           

            //operasi variabel
            hasilTambah = codeA + codeB + codeC;
            hasilKali = codeA * codeB * codeC;
            //hasilKurang = codeA - codeB - codeC;
            //hasilBagi = codeA / codeB / codeC;
        }

        static void Intro()
        {
            Init();
            if (bGameStart && kesempatan != 1)
            {
                TryAgain();
            }
            Console.WriteLine("Anda adalah aggen rahasia yang bertugas mendapatkan data dari server...");
            Console.WriteLine("Akses ke server membutuhkan password yang tidak di ketahui..");
            Console.WriteLine("Password terdiri dari 3 angka");
            Console.WriteLine("Jika Ditambahkan hasilnya "+hasilTambah);
            Console.WriteLine("Jika dikalikan hasilnya "+hasilKali);
        }

        static void PlayGame()
        {
            Intro();
            Console.Write("\nMasukkan Kode Pertama : "); tebakanA = Console.ReadLine();
            Console.Write("Masukkan Kode Kedua : "); tebakanB = Console.ReadLine();
            Console.Write("Masukkan Kode Ketiga : "); tebakanC = Console.ReadLine();

            if (tebakanA == codeA.ToString() && tebakanB == codeB.ToString() && tebakanC == codeC.ToString())
            {
                Console.WriteLine("Yaaa Andaaa Benarr..");
                ShowEnd(true);
            }
            else
            {
                Console.WriteLine("Yahh salah nih..");
            }
        }

        static void ShowEnd(bool b)
        {
            Console.Clear();
            if (b && kesempatan <= 3)
            {
                Console.WriteLine("Jawaban Anda Benar!\n\nYeyy menang!!");
            }
            else
            {
                Console.WriteLine("Kesempatan Habis.\n\nYaahh Kalah!!");
            }
            bGameStart = false;
        }

        static void TryAgain()
        {
            Console.Clear();
            Console.WriteLine("Salah, Coba lagi!\nKesempatan anda tinggal " + (4 - kesempatan) + "\n");
        }
    }
} 